import 'package:flutter/material.dart';

import 'src/shared/app.dart';

void main() {
  runApp(const MyApp());
}
